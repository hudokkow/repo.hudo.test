# resource.keyboard.italian
Italian keyboard layout for [Kodi](http://www.kodi.tv/).
