# resource.keyboard.korean
Korean keyboard layout for [Kodi](http://www.kodi.tv/).
