# resource.keyboard.czech
Czech keyboard layout for [Kodi](http://www.kodi.tv/).
