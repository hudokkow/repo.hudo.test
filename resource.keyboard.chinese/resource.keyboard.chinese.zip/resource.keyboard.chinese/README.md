# resource.keyboard.chinese
Chinese keyboard layout for [Kodi](http://www.kodi.tv/).
