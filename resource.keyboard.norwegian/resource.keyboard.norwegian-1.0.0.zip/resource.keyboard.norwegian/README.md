# resource.keyboard.norwegian
Norwegian keyboard layout for [Kodi](http://www.kodi.tv/).
