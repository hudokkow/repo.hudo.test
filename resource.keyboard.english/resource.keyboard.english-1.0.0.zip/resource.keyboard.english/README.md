# resource.keyboard.english
English keyboard layout for [Kodi](http://www.kodi.tv/).
