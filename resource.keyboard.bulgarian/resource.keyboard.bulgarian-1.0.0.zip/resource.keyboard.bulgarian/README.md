# resource.keyboard.bulgarian
Bulgarian keyboard layout for [Kodi](http://www.kodi.tv/).
