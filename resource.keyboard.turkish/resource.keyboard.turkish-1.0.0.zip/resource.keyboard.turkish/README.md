# resource.keyboard.turkish
Turkish keyboard layout for [Kodi](http://www.kodi.tv/).
