# resource.keyboard.thai
Thai keyboard layout for [Kodi](http://www.kodi.tv/).
