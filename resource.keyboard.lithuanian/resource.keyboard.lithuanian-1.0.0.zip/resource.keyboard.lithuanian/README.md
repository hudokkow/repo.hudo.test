# resource.keyboard.lithuanian
Lithuanian keyboard layout for [Kodi](http://www.kodi.tv/).
