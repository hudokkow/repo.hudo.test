# resource.keyboard.hebrew
Hebrew keyboard layout for [Kodi](http://www.kodi.tv/).
