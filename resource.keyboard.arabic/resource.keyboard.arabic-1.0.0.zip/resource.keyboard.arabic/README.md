# resource.keyboard.arabic
Arabic keyboard layout for [Kodi](http://www.kodi.tv/).
