# resource.keyboard.swedish
Swedish keyboard layout for [Kodi](http://www.kodi.tv/).
