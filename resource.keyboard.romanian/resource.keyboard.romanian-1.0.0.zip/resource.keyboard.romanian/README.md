# resource.keyboard.romanian
Romanian keyboard layout for [Kodi](http://www.kodi.tv/).
