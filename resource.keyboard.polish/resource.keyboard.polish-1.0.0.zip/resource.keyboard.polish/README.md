# resource.keyboard.polish
Polish keyboard layout for [Kodi](http://www.kodi.tv/).
