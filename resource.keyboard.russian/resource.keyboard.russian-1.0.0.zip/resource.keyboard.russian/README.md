# resource.keyboard.russian
Russian keyboard layout for [Kodi](http://www.kodi.tv/).
