# resource.keyboard.spanish
Spanish keyboard layout for [Kodi](http://www.kodi.tv/).
