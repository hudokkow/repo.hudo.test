# resource.keyboard.danish
Danish keyboard layout for [Kodi](http://www.kodi.tv/).
