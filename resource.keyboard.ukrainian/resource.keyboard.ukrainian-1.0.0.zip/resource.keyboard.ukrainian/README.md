# resource.keyboard.ukrainian
Ukrainian keyboard layout for [Kodi](http://www.kodi.tv/).
