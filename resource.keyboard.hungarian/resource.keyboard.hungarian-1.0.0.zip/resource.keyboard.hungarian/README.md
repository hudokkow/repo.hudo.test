# resource.keyboard.hungarian
Hungarian keyboard layout for [Kodi](http://www.kodi.tv/).
