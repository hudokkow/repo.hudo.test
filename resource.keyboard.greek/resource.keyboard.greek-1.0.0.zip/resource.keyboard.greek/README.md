# resource.keyboard.greek
Greek keyboard layout for [Kodi](http://www.kodi.tv/).
