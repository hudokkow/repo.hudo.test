# resource.keyboard.silesian
Silesian keyboard layout for [Kodi](http://www.kodi.tv/).
