# resource.keyboard.croatian
Croatian keyboard layout for [Kodi](http://www.kodi.tv/).
