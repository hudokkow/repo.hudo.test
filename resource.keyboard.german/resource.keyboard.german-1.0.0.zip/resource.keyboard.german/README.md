# resource.keyboard.german
German keyboard layout for [Kodi](http://www.kodi.tv/).
