# resource.keyboard.portuguese
Portuguese keyboard layout for [Kodi](http://www.kodi.tv/).
