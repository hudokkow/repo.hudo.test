# resource.keyboard.slovak
Slovak keyboard layout for [Kodi](http://www.kodi.tv/).
