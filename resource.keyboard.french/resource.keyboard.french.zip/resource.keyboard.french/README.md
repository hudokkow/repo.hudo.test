# resource.keyboard.french
French keyboard layout for [Kodi](http://www.kodi.tv/).
