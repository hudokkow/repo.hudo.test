# resource.keyboard.slovenian
Slovenian keyboard layout for [Kodi](http://www.kodi.tv/).
